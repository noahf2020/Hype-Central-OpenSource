# supbot

demo link https://youtu.be/pwq1euMuN-s



download file and open into a text editor
