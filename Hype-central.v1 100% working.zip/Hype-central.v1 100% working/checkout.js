var pageLoc = location.href;
var typeWaitTime = "50";

var checkoutInfo = {};

chrome.runtime.onMessage.addListener(gotInfo);

if(!checkoutInfo.name)
{
    console.log("Give me info");
    chrome.runtime.sendMessage("giveInfo");
}

var checkoutWaitTime = checkoutInfo.checkoutDelay;

//getting items on checkout page
var cpItems = {
    name: document.getElementById("order_billing_name"),
    email: document.getElementById("order_email"),
    tel: document.getElementById("order_tel"),
    address: document.getElementById("bo"),
    apt: document.getElementById("oba3"),
    zip: document.getElementById("order_billing_zip"),
    city: document.getElementById("order_billing_city"),
    state: document.getElementById("order_billing_state"),
    country: document.getElementById("order_billing_country"),
    ccNum: document.getElementById("nnaerb"),
    ccMonth: document.getElementById("credit_card_month"),
    ccYear: document.getElementById("credit_card_year"),
    CVV: document.getElementById("orcer"),
    checkBox: document.getElementById("order_terms")
};

//getting true cc number and cvv element bc they might change
if(pageLoc == "https://www.supremenewyork.com/checkout")
{
    //getting cc number
    var items = document.getElementsByClassName("string required");

    for(let i = 0; i < items.length; i++)
    {
        if(items[i].placeholder == "number")
        {
            cpItems.ccNum = items[i];
        }
    }

    //getting cvv
    var items = document.getElementsByClassName("string required");

    for(let i = 0; i < items.length; i++)
    {
        if(items[i].placeholder == "CVV")
        {
            cpItems.CVV = items[i];
        }
    }
}

//runs when got info from background
function gotInfo(info, sender, sendResponse)
{   //bool to see if checking out
    var checkingout = false;
    //initializes data on btn start
    if(info == "start")
    {
        //telling background script to give me info
        chrome.runtime.sendMessage("giveInfo");
    }
    else if(info.name)
    {
        //setting the info
        console.log("setting info");
        console.log(info);
        checkoutInfo = info;

        //running checkout page autofill
        if(pageLoc == "https://www.supremenewyork.com/checkout")
        {
            setTimeout(checkoutAutoFill(checkoutInfo), 500);
            checkingout = true;
        }

        //if not on right category switch to right one
        if(pageLoc != "https://www.supremenewyork.com/shop/all/" + info.category && !checkingout)
        {
            location.href = "https://www.supremenewyork.com/shop/all/" + info.category;
        }

        //get selects item
        getItem();
    }
}

function checkoutAutoFill(info)
{
    //inputting all info into checkout form
    console.log(info);
    cpItems.name.value = info.name;
    cpItems.email.value = info.email;
    cpItems.tel.value = info.tel;
    cpItems.address.value = info.address;
    cpItems.apt.value = info.apt;
    cpItems.zip.value = info.zip;
    cpItems.city.value = info.city;
    cpItems.state.value = info.state;
    cpItems.country.value = info.country;
    cpItems.ccNum.value = info.ccNum;
    cpItems.ccMonth.value = info.ccMonth;
    cpItems.ccYear.value = info.ccYear;
    cpItems.CVV.value = info.CVV;

    //checking agree box
    cpItems.checkBox.checked = true;

    processPayment(checkoutWaitTime);

    console.log("Checkout Done");
}

//Not used -- to type out each letter individually
async function waitType(object, timeMS, input)
{
    object.value = "";
    if(input != "" || input != undefined)
    {
        var inputArr = input.split("");
        for(let i = 0; i < inputArr.length; i++)
        {
            await sleep(timeMS);
            object.value += inputArr[i];
        }
    }
}

//pause before checkout btn is pressed
async function processPayment(waitMs)
{
    await sleep(waitMs);
    $('[name="commit"]').click();
}

//sleep for process payment
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }