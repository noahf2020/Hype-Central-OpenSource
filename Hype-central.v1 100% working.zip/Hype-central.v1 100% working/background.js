console.log("backgroundReady");
chrome.tabs.onActivated.addListener(tab => {
    chrome.tabs.get(tab.tabId, current_tab_info => {
       if (/^https:\/\/kith/.test(current_tab_info.url)) {
            chrome.tabs.executeScript(null, {file: 'shopifyCon.js'}, () => console.log('success'))
        }
    }
)});

var checkoutInfo = {};
var stop = false;

function getMessage(message, sender, sendResponse)
{
    if(message.name)
    {
        checkoutInfo = message;
        console.log("got checkout info");
        console.log(checkoutInfo);
        sendInfo("start");
        stop = false;
    }

    if(message == "stop")
    {
        stop = true;
    }

    if(message == "giveInfo" && !stop)
    {
        console.log("sending");
        sendInfo(checkoutInfo);
    }
}

//sending info to content scripts
function sendInfo(info)
{
    //for tabs
    let params = {
        active: true,
        currentWindow: true
    };

    //getting tabs to send message
    chrome.tabs.query(params, gotTab);

    //part where message sends
    function gotTab(tabs) 
    {
        chrome.tabs.sendMessage(tabs[0].id, info);
        console.log("sending info");
        console.log(info);
    }
}

//listens to get message
chrome.runtime.onMessage.addListener(getMessage);