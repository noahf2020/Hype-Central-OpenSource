document.getElementById("shippingBtn").onclick = function () 
{
    var shipInfo = document.getElementById("shipInfo");
    
    if(shipInfo.style.display == "block")
    {
        shipInfo.style.display = "none";
    }
    else
    {
        shipInfo.style.display = "block";
    }
    resizeForm();
}

document.getElementById("cardBtn").onclick = function () 
{
    var shipInfo = document.getElementById("cardInfo");
    
    if(shipInfo.style.display == "block")
    {
        shipInfo.style.display = "none";
    }
    else
    {
        shipInfo.style.display = "block";
    }
    resizeForm();
}

document.getElementById("settingsBtn").onclick = function () 
{
    var shipInfo = document.getElementById("settingsInfo");
    
    if(shipInfo.style.display == "block")
    {
        shipInfo.style.display = "none";
    }
    else
    {
        shipInfo.style.display = "block";
    }
    resizeForm();
}

function resizeForm()
{
    var height = $("#startBot").position();
    document.body.style.height = height.top + 50 + "px";
    window.resizeTo(300, height);
}