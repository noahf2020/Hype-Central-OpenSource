function getItem()
{
    //setting values
    var keyWord = checkoutInfo.keyWord;
    var color = checkoutInfo.color;

    var itemFound = false;

    console.log("Getting Item!");

    //getting all titles for items by class
    var items = document.getElementsByClassName("name-link");

    console.log(items);
    console.log(items.length);

    //running through all elements
    for(let i = 0; i < items.length; i+=2)
    {
        //checking if right keyword + right color word
        if(items[i].innerHTML.includes(keyWord) && items[i + 1].innerHTML.includes(color))
        {
            //clicking it
            items[i].click();
            console.log("found item" + items[i]);
            console.log("with color" + items[i + 1]);
            itemFound = true;
            break;
        }
        console.log("Not found at " + items[i] + "color:" + items[i+1] + "going to next item");
        console.log(i);
        itemFound = false;
    }

    if(itemFound)
    {
        selectSize();
    }
}


//gets size and clicks add to cart
function selectSize()
{
    var sizeBox;
    var size = checkoutInfo.size;

    setTimeout(function () {
        //getting box
        sizeBox = document.getElementById("s");
        if(sizeBox != null)
        {
            //running through all sizes
            if(size != "N/A")
            {
                for(let i = 0; i < sizeBox.options.length; i++)
                {
                    if(sizeBox.options[i].innerHTML == size)
                    {
                        console.log("Selecting " + size);
                        //selecting size
                        sizeBox.options[i].selected = true;
                        $("[name='commit']").click();
                        //redir to checkout
                        setTimeout(function () {
                            location.href = "https://www.supremenewyork.com/checkout";
                        }, 500);
                    }
                }
            }
            else
            {
                //Clicks add to cart
                $("[name='commit']").click();
                //redir to checkout
                setTimeout(function () {
                    location.href = "https://www.supremenewyork.com/checkout";
                }, 500);
            }

        }
    }, 1250);
}
